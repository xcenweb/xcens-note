<?php
function data_gl($value) { 
	/**
	 * ps.防注入过滤，参考自互联网。
     * @author: 小岑
     * @param: mixed $value 参数值
     * @version [1.0] [2020-4-1]
     */
    if(!get_magic_quotes_gpc()) {
    $value = addslashes($value);
    } 
    $value = str_replace("_", "\_", $value); 
    $value = str_replace("%", "\%", $value); 
    $value = nl2br($value); 
    $value = htmlspecialchars($value); 
    return $value; 
}

function get_maintitle($con){
    /**
     * 获取主标题
     * @author: 小岑
     * @version [1.0] [2020-4-1]
     */
    $sql = "SELECT * FROM xc_note_admin WHERE id='1'";
    $data = mysqli_query($con,$sql);
    while($row = mysqli_fetch_assoc($data)){
        $data = $row['maintitle'];
    }
    return $data;
}

function putnote_sql_form($con,$title,$note,$sort,$rem,$comm,$look){
    $time = date("Y年m月d日 H:i:s");
    $sql = "INSERT INTO xc_note (id,Title,Note,Sort,Time,rem,comm,look)
    VALUES (null,'$title','$note','$sort','$time','$rem','$comm','$look')";
    if (mysqli_query($con, $sql)) {
    echo "新记录插入成功";
    } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
}


function get_webtitle($con,$maintitle){
    /**
     * 组合成html title
     * @author: 小岑
     * @version [1.0] [2020-4-1]
     */
    $sql = "SELECT * FROM xc_note_admin WHERE id='1'";
    $data = mysqli_query($con,$sql);
    while($row = mysqli_fetch_assoc($data)){
        $data = $row['Subtitle'];
    }
    return $maintitle."-".$data;
}

function get_sql_num($con,$ku){
    /**
     * 数据库数据计数
     * @author 小岑
     * @version [1.0] [2020-4-2] 
     */
    $sql = "SELECT COUNT(*) FROM ".$ku." "; //获取某一张表的所有数据
    $res = $con->query($sql);
    $data = $res->fetch_all();
    return $data[0] [0];
}
