
<div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
	<div class="mdui-toolbar mdui-color-theme-accent">
        <a href="javascript:;" mdui-drawer="{target: '#drawer'}" class="mdui-btn mdui-ripple mdui-btn-icon"><i class="mdui-icon material-icons">menu</i></a>
        <a href="./" class="mdui-typo-title">后台管理</a>
        <div class="mdui-toolbar-spacer"></div>
        <a href="javascript:;" mdui-dialog="{target: '#example-1'}" class="mdui-btn mdui-ripple mdui-btn-icon"><i class="mdui-icon material-icons">&#xe879;</i></a>
    </div>
</div>